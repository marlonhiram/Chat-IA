# CONTEXTO DO PROJETO — DKN Chat (Suh)
> Última atualização: 26/05/2026

## 1. Visão Geral

Chat de IA para o site do Grupo Sul Brasil DKN. Assistente virtual com persona "Suh" responde dúvidas técnicas e comerciais sobre TNT, coleta dados do lead progressivamente e encaminha para representante regional via WhatsApp. Projeto isolado do site Next.js original (não aprovado) e hospedado na Vercel. Integração futura prevista com WordPress via iframe/widget.

**Empresa**: Grupo Sul Brasil — indústria de Tecido Não-Tecido (TNT), Caçador/SC, fundada em 1992, certificada ABNT NBR ISO 9001:2015. DKN é a marca do produto, não o nome da empresa. ERP Delphi 7 legado, sem API disponível.

**URL produção**: https://project-0qgvo.vercel.app
**Painel de monitoramento**: https://project-0qgvo.vercel.app/painel

---

## 2. Contas e Serviços

| Serviço | Conta | Finalidade |
|---|---|---|
| Vercel | yurnero14 | Hospedagem do chat |
| Google AI Studio | — | Chave da API Gemini |
| Google Cloud | projeto `dkn-chat` | Service Account para Sheets |
| Google Sheets | yurnero14@gmail.com | Histórico de conversas + métricas |

**Planilha**: DKN Chat — Histórico de Conversas
**Sheet ID**: `1lM0SyPl-vRG9o7FPikDEcKzoS5h8uoNW7NlwYpZxHP0`

---

## 3. Stack Técnica

- **Framework**: Next.js 14.2.3 (App Router)
- **Linguagem**: TypeScript
- **Modelo de IA principal**: Gemini 2.5 Flash (Google) — preview
- **Modelo de IA fallback**: Gemini 2.0 Flash (Google) — ativado na 3ª tentativa em caso de 503
- **Hospedagem**: Vercel (plano Hobby — limite 10s por função serverless, 30s para /api/chat via vercel.json)
- **Runtime Node.js na Vercel**: 20.x
- **Histórico de conversas**: Google Sheets via googleapis SDK

---

## 4. Variáveis de Ambiente

| Variável | Onde | Observação |
|---|---|---|
| `GEMINI_API_KEY` | `.env.local` + Vercel | Chave da API Gemini |
| `GOOGLE_SERVICE_ACCOUNT_EMAIL` | `.env.local` + Vercel | Email da service account |
| `GOOGLE_PRIVATE_KEY` | `.env.local` + Vercel | Com aspas duplas no valor na Vercel |
| `GOOGLE_SHEET_ID` | `.env.local` + Vercel | ID da planilha de histórico |
| `PAINEL_SENHA` | `.env.local` + Vercel | Senha de acesso ao painel (`dkn2024`) |

**Atenção**: `GOOGLE_PRIVATE_KEY` deve ser salva **com aspas duplas** no painel da Vercel para processar corretamente as quebras de linha `\n`.

---

## 5. Arquitetura e Design de Sistema

Arquitetura em duas etapas paralelas: Facilitador classifica a mensagem enquanto o agente Comercial já começa a processar simultaneamente, reduzindo latência total para ~3-4s.

```
Request → Facilitador + Comercial (paralelo via Promise.allSettled)
        ↓
Se tipo == 'comercial' → usa resposta do Comercial já pronta
Se tipo != 'comercial' → chama agente correto (sequencial)
        ↓
Salva conversa no Google Sheets (await — não em background)
        ↓
Retorna resposta ao frontend com uso de tokens e custo acumulado da sessão
```

Agentes definidos como objetos TypeScript em `lib/agents/`. Sem framework externo. Cada agente é independente.

**Regra operacional**: Nenhum código, arquivo ou relatório deve ser gerado sem consultar o responsável primeiro. Toda alteração deve ser cirúrgica — indicando exatamente qual arquivo, como está e como deve ficar.

**5 camadas de segurança**:
1. Rate limiting por IP (20 msgs/hora, janela de 60min)
2. Validação de qualidade da mensagem (mín. 2 chars, sem repetição, sem só símbolos)
3. Proteção contra prompt injection (8 padrões regex)
4. Anti-alucinação no prompt (regras explícitas + temperatura 0.2)
5. Timeout (9s) + histórico limitado (últimas 10 mensagens)

---

## 6. Banco de Dados

Não há banco de dados relacional. Histórico de conversas salvo em Google Sheets.

**Estrutura da planilha** (colunas A a P):

| Col | Campo |
|---|---|
| A | Session ID |
| B | Data/Hora |
| C | Nome |
| D | Cidade |
| E | UF |
| F | Segmento |
| G | Empresa |
| H | Total Mensagens |
| I | Encaminhamento |
| J | Agente |
| K | IP |
| L | Transcrição |
| M | Custo Sessão (R$) |
| N | Custo Total Acumulado (R$) |
| O | Resultado (Sucesso/Falha) |
| P | Observação |

- Uma linha por sessão, atualizada a cada mensagem
- Session ID gerado no frontend: `sess_${Date.now()}_${random}`
- Busca por Session ID na coluna A para decidir criar ou atualizar linha
- Colunas O e P preservadas ao atualizar (não sobrescritas pelo código)

---

## 7. Autenticação e Permissões

Sem autenticação de usuário no chat. Proteção via rate limiting por IP.

Painel de monitoramento (`/painel`) protegido por senha simples via header `x-painel-senha`. Senha definida na variável `PAINEL_SENHA`.

Google Sheets autenticado via `google.auth.GoogleAuth` com service account (chave PKCS#8 `BEGIN PRIVATE KEY`).

---

## 8. Integrações Externas

**Gemini 2.5 Flash (Google) — modelo principal**
- Finalidade: geração de respostas e classificação de intenção
- Chamada: REST direto (`fetch` para `generativelanguage.googleapis.com`)
- Credencial: `GEMINI_API_KEY`
- Retry: 3 tentativas com backoff exponencial + jitter (1500ms±500, 3000ms±500, 3500ms fixo)
- Fallback de modelo: na 3ª tentativa, troca automaticamente para `gemini-2.0-flash`
- Captura `usageMetadata` (promptTokenCount, candidatesTokenCount) para cálculo de custo
- Loga `finishReason` quando diferente de `STOP` para detectar cortes por MAX_TOKENS

**Gemini 2.0 Flash (Google) — modelo fallback**
- Ativado automaticamente na 3ª tentativa quando o 2.5 Flash retorna 503
- Mesma chamada REST, mesmo endpoint, apenas o nome do modelo muda na URL
- Qualidade ligeiramente inferior ao 2.5 Flash — aceitável para manter atendimento funcionando

**Google Sheets API**
- Finalidade: salvar histórico de conversas e métricas de custo
- Chamada: SDK `googleapis` v4
- Credencial: `GOOGLE_SERVICE_ACCOUNT_EMAIL` + `GOOGLE_PRIVATE_KEY`
- Leitura: range `A:P` (16 colunas)
- Falha silenciosa: erro logado no console, não afeta resposta ao usuário

**WhatsApp (links diretos)**
- Finalidade: encaminhar cliente para representante ou suporte
- Botão [WHATSAPP]: link extraído da resposta da Suh via regex (`wa.me` / `api.whatsapp.com`)
- Botão [DISTRIBUIDOR]: renderiza botões individuais por distribuidor mencionado na resposta
- Links e nome da Andreia removidos do texto exibido no chat (limpeza no renderMsg)
- Fallback do link [WHATSAPP]: número da Andreia (`554935611505`) se nenhum link encontrado
- Mensagem pré-preenchida montada dinamicamente com dados coletados na conversa

---

## 9. Estrutura de Pastas

```
dkn-chat/
├── .env.local
├── .gitignore
├── .node-version
├── next.config.js
├── package.json
├── tsconfig.json
├── vercel.json            (maxDuration: 30s para /api/chat)
├── app/
│   ├── api/
│   │   ├── chat/
│   │   │   └── route.ts       (servidor principal + retry/fallback de modelo + captura de tokens)
│   │   └── painel/
│   │       └── route.ts       (GET: lê conversas | PATCH: atualiza resultado e observação)
│   ├── painel/
│   │   └── page.tsx           (painel de monitoramento com senha)
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   └── ChatWidget.tsx         (componente React + botões de distribuidor individuais + limpeza de links)
├── lib/
│   ├── agents/
│   │   ├── comercial.ts       (prompt da Suh — tokens_max: 4096, temperatura: 0.2)
│   │   ├── facilitador.ts     (classificador — tokens_max: 1024, temperatura: 0.1)
│   │   ├── rh.ts              (agente RH — tokens_max: 1024, temperatura: 0.2)
│   │   ├── compras.ts         (agente Compras — tokens_max: 1024, temperatura: 0.2)
│   │   ├── index.ts           (central de agentes + pegarAgentePorClassificacao)
│   │   └── tipos.ts           (interfaces Agent, TipoAgente, ClassificacaoResult)
│   └── google-sheets.ts       (salvarConversa + lerConversas + atualizarResultado + atualizarObservacao)
└── scripts/
    ├── testar-suh.mjs
    └── testar-conversas.mjs
```

---

## 10. Fluxos Implementados

**Fluxo principal (mensagem do usuário)**
1. Frontend envia `{ messages, sessionId, custoSessaoUSD }` para `POST /api/chat`
2. Rate limiting valida IP
3. Validação de qualidade filtra mensagens com menos de 2 chars ou inválidas
4. Regex bloqueia prompt injection
5. Facilitador + Comercial chamados em paralelo
6. Facilitador retorna JSON limpo (markdown removido antes do parse)
7. Se tipo != comercial → chama agente correto sequencialmente
8. Tokens consumidos capturados via `usageMetadata`
9. Custo da sessão calculado e acumulado (USD → R$ câmbio 5,50)
10. Resposta retornada ao frontend com `uso: { inputTokens, outputTokens, custoSessaoUSD }`
11. Conversa salva/atualizada no Google Sheets com custo

**Fluxo de retry e fallback de modelo**
- Tentativa 1: `gemini-2.5-flash` — aguarda 1500ms±500 em caso de 503
- Tentativa 2: `gemini-2.5-flash` — aguarda 3000ms±500 em caso de 503
- Tentativa 3: `gemini-2.0-flash` (fallback automático) — sem retry adicional
- Se todas falharem: lança erro → frontend exibe mensagem de fallback

**Fluxo de encaminhamento**
- Suh coleta nome → cidade/estado → empresa progressivamente
- Ao detectar intenção de compra: informa pedido mínimo R$10.000 antes de encaminhar
- Se cliente não souber especificações técnicas: encaminha representante imediatamente
- Encaminha representante por estado (SP/PR/SC) ou Andreia (demais)
- Dúvida técnica fora da base (produto não existente na linha): encaminha Andreia imediatamente, sem qualificar volume
- Se cliente demonstrar intenção de compra de produto conhecido com especificação customizada: encaminha representante (não Andreia)
- Representante interessado em parceria comercial: encaminha sempre para Anderson Nonato

**Fluxo de botões de distribuidor**
- Suh menciona distribuidores na resposta + tag [DISTRIBUIDOR]
- ChatWidget detecta quais distribuidores foram mencionados pelo nome no texto
- Renderiza botão individual para cada distribuidor mencionado (com link wa.me correto)
- Se nenhum distribuidor identificado no texto: exibe botões de todos os distribuidores

**Fluxo de fallback de usuário**
- 1ª falha técnica: "pode enviar sua mensagem novamente"
- 2ª falha consecutiva: "dificuldades técnicas" + botão WhatsApp para Andreia
- Dúvida sem resposta na base: encaminha Andreia + [WHATSAPP]
- Cliente pede atendente humano + tem estado coletado: encaminha representante imediatamente

**Painel de monitoramento**
- Acesso via `/painel` com senha
- Exibe métricas: total sessões, sucessos, falhas, taxa de sucesso, custo total acumulado
- Lista conversas com transcrição expandível
- Botões ✅/❌ gravam resultado na coluna O do Sheets via PATCH /api/painel
- Campo de observação salvo na coluna P via PATCH /api/painel
- Observações carregadas corretamente ao fazer login (estado inicializado no `entrar()`)
- Filtros: Todos, Pendentes, Sucesso, Falha

**Roteamento de agentes**
- `comercial` → Suh (Agente Comercial)
- `rh` → Agente RH (processo seletivo + contato RH)
- `compras` → Agente Compras (fornecedores → contato Josemar)
- `financeiro` → fallback Suh (agente não implementado)
- `transporte` → fallback Suh (agente não implementado)
- `institucional` → fallback Suh

---

## 11. Contratos de Interface

**POST /api/chat**
```
Request:  { messages: [{role, content}][], sessionId: string, custoSessaoUSD: number }
Response: { content: [{type:'text', text:string}], agente_usado: string, versao_agente: string, uso: { inputTokens: number, outputTokens: number, custoSessaoUSD: number } }
```

**GET /api/painel**
```
Header:   x-painel-senha: string
Response: { conversas: Conversa[] }
```

**PATCH /api/painel**
```
Header:   x-painel-senha: string
Body:     { linha: number, resultado?: 'Sucesso' | 'Falha', observacao?: string }
Response: { ok: true }
```

**Tags de ação** (processadas no ChatWidget):
- `[WHATSAPP]` → botão verde com link extraído da resposta da Suh
- `[DISTRIBUIDOR]` → botões verdes individuais por distribuidor mencionado no texto
- `[TRABALHE_CONOSCO]` → botão azul para `/trabalhe-conosco`
- `[PAGINA_EMPRESA]` → botão azul para `/empresa`
- `[SEG:NomeSegmento]` → extraído e usado no link WhatsApp, removido do texto exibido

**Distribuidores registrados no ChatWidget**:
- Jean (PR) — `5541991838361`
- Dem Bas (RS) — `5551935872363`
- TNT Paraná (PR) — `5543921026096`
- LJ Distribuição (MG) — `5532935413485`
- Zantex (SP) — `5511944234241`

---

## 12. Ambiente, Deploy e CI/CD

**Local**:
```bash
npm run dev   # http://localhost:3000
```

**Produção (Vercel)**:
```bash
npx vercel --prod
```

Sem CI/CD automatizado. Deploy manual via CLI. Variáveis de ambiente configuradas manualmente no painel da Vercel.

**Testes automatizados**:
```bash
node scripts/testar-suh.mjs
node scripts/testar-conversas.mjs
```

---

## 13. Middleware e Interceptors

N/A — sem middleware Next.js configurado. Validações implementadas diretamente no `route.ts`.

---

## 14. Riscos e Limitações Conhecidas

- **Gemini 2.5 Flash em preview**: modelo instável em horário comercial americano (13h-18h BRT). Mitigado por retry com backoff + fallback para Gemini 2.0 Flash na 3ª tentativa.
- **Gemini 2.0 Flash como fallback**: qualidade inferior ao 2.5 Flash. Usado apenas quando o principal falha — aceitável para manter atendimento.
- **MAX_TOKENS em conversas longas**: prompt do Comercial ~5000 tokens de input. `tokens_max: 4096` dá margem, mas conversas muito longas com histórico de 10 mensagens podem ainda pressionar o limite.
- **Facilitador com tokens_max: 1024**: Gemini 2.5 Flash consome tokens internos de "thinking" antes do output visível, causando MAX_TOKENS com limites menores. 1024 é o mínimo seguro.
- **Extração de dados por regex**: nome, cidade, UF, empresa extraídos por regex — pode falhar em frases não previstas. Nome capturado apenas quando cliente usa padrões explícitos ("meu nome é", "me chamo", etc.).
- **Session ID no frontend**: perdido ao fechar e reabrir o chat. Cada abertura cria nova sessão.
- **Google Sheets como "banco"**: funcional para fase de testes. Sem proteção contra concorrência — duas sessões simultâneas podem gerar conflito de linha.
- **Logs da Vercel somem após 1 hora (plano Hobby)**: erros 503, MAX_TOKENS e falhas no Sheets invisíveis após esse período.
- **GOOGLE_PRIVATE_KEY com aspas duplas na Vercel**: gambiarra necessária. Qualquer redeploy que resetar a variável quebrará a integração com o Sheets.
- **Custo acumulado via última linha da coluna N**: se houver linhas fora de ordem no Sheets, o acumulado pode ficar incorreto.
- **Câmbio fixo R$5,50**: diverge do real ao longo do tempo.

---

## 15. Pendências Abertas

**Agentes pendentes de informações:**
- Agente Financeiro — aguardando dados do departamento
- Agente Transporte — nome: Trans Modena, aguardando detalhes

**Representantes:**
- Receber lista completa (~20 representantes) com estado e WhatsApp
- Confirmar cobertura Jean vs TNT Paraná no PR
- Definir fallback para estados sem representante

**Distribuidores:**
- Confirmar se contatos Dem Bas e LJ Distribuição são WhatsApp ou fixo (wa.me pode não funcionar para fixo)
- Definir cobertura para estados sem distribuidor

**Agente RH:**
- Substituir endereço de teste pelo endereço real da GSB

**Produto:**
- Embedar chat no WordPress via Elementor
- Implementar versão robótica (sem persona Suh) para comparação A/B
- Formulário Trabalhe Conosco
- Few-Shot Learning com conversas reais aprovadas no painel

**Infraestrutura:**
- Migrar Google Sheets para PostgreSQL quando volume aumentar
- Separar planilha de testes e produção
- Unificar chave de API Gemini entre local e Vercel para dashboard consolidado
- Implementar monitoramento persistente de erros (substituir logs da Vercel)
