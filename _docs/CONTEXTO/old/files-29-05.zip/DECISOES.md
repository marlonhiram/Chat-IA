# DECISÕES TÉCNICAS — DKN Chat (Suh)
> Última atualização: 26/05/2026

## [DEC-001] — Gemini 2.5 Flash como modelo de IA principal
**Data:** 08/05/2026
**Status:** Ativa
**Contexto:** Necessidade de modelo de IA para classificação e resposta em chat de suporte comercial. Orçamento limitado.
**Decisão:** Gemini 2.5 Flash em vez de Claude ou GPT-4.
**Consequências:** Custo ~40× menor que Claude Sonnet. Suficiente para classificação e FAQ técnico. Modelo ainda em preview — sujeito a erros 503 em horários de pico americano. Qualidade ligeiramente inferior em raciocínio complexo — irrelevante para o caso de uso.

---

## [DEC-002] — Agentes como objetos TypeScript (sem framework)
**Data:** 08/05/2026
**Status:** Ativa
**Contexto:** Múltiplos agentes necessários. Avaliar uso de LangChain ou CrewAI.
**Decisão:** Agentes como objetos TypeScript em `lib/agents/`. Sem LangChain, sem CrewAI.
**Consequências:** Zero dependências extras. Controle total do fluxo. Agentes independentes. Migração para framework mais complexa se necessário no futuro.

---

## [DEC-003] — Persona "Suh" para o agente comercial
**Data:** 12/05/2026
**Status:** Ativa
**Contexto:** Debate sobre ter ou não persona humanizada. Risco ético de enganar cliente.
**Decisão:** Persona Suh com honestidade — confirma ser IA se perguntada diretamente.
**Consequências:** Melhor experiência do usuário. Sem risco jurídico (LGPD). Temperatura 0.2 para reduzir alucinações.

---

## [DEC-004] — Chamadas paralelas Facilitador + Comercial
**Data:** 19/05/2026
**Status:** Ativa
**Contexto:** Vercel Hobby limita funções serverless a 10s. Chamadas sequenciais somavam 5-8s.
**Decisão:** `Promise.allSettled([facilitador, comercial])` em paralelo. Se tipo for 'comercial', usa resposta já pronta.
**Consequências:** Tempo total ~3-4s. Custo dobrado para mensagens comerciais. Trade-off aceito dado volume baixo.

---

## [DEC-005] — Google Sheets como armazenamento de histórico
**Data:** 19/05/2026
**Status:** Ativa
**Contexto:** Necessidade de capturar histórico para fase de testes. Banco relacional adiado para pós-aprovação do MVP.
**Decisão:** Google Sheets via googleapis SDK. Uma linha por sessão, atualizada a cada mensagem. 16 colunas (A-P).
**Consequências:** Zero custo. Visível em tempo real. Não escala para alto volume. Migração para PostgreSQL prevista após aprovação.

---

## [DEC-006] — GOOGLE_PRIVATE_KEY com aspas duplas na Vercel
**Data:** 19/05/2026
**Status:** Ativa
**Contexto:** Chave PKCS#8 causava erro `DECODER routines::unsupported` na Vercel com Node.js 20.
**Decisão:** Salvar valor com aspas duplas literais no painel da Vercel. Código remove aspas e normaliza `\n`.
**Consequências:** Gambiarra necessária. Qualquer redeploy que resetar a variável perderá as aspas e quebrará a integração com o Sheets.

---

## [DEC-007] — salvarConversa com await (não em background)
**Data:** 19/05/2026
**Status:** Ativa
**Contexto:** Vercel encerra funções serverless imediatamente após o `return`. Chamada em background era cortada.
**Decisão:** `await Promise.allSettled([salvarConversa(...)])` antes do `return`.
**Consequências:** Adiciona ~500ms-1s de latência. Aceitável dado o limite de 30s configurado no `vercel.json`.

---

## [DEC-008] — Retry com backoff exponencial + jitter para erros 503
**Data:** 21/05/2026 — atualizada em 26/05/2026
**Status:** Ativa (substituiu intervalo fixo de 2s → backoff simples → backoff com jitter)
**Contexto:** Retry com intervalo fixo consumia margem desnecessária. Backoff simples sem jitter causava thundering herd — múltiplas requisições simultâneas batendo no Gemini no mesmo instante após o delay.
**Decisão:** Backoff exponencial com jitter aleatório:
- Tentativa 1: 1500ms + jitter (0-500ms)
- Tentativa 2: 3000ms + jitter (0-500ms)
- Tentativa 3: 3500ms fixo (fallback de modelo — ver DEC-014)
**Consequências:** Distribui melhor as requisições em pico. Comportamento idêntico em caso de sucesso na 1ª tentativa.

---

## [DEC-009] — Captura de tokens e custo via usageMetadata do Gemini
**Data:** 21/05/2026
**Status:** Ativa
**Contexto:** Necessidade de visibilidade real de custo por sessão e acumulado para apresentar à diretoria.
**Decisão:** Capturar `promptTokenCount` e `candidatesTokenCount` do `usageMetadata` retornado pelo Gemini. Calcular custo em USD e converter para R$ (câmbio fixo R$5,50). Custo acumulado salvo na coluna N do Sheets.
**Consequências:** Custo visível por sessão no frontend e acumulado no Sheets. Câmbio fixo pode divergir do real ao longo do tempo.

---

## [DEC-010] — Painel de monitoramento em /painel
**Data:** 21/05/2026
**Status:** Ativa
**Contexto:** Necessidade de ferramenta para marcar conversas como Sucesso/Falha durante fase de testes e apresentar dados à diretoria.
**Decisão:** Página Next.js em `/painel` com senha simples (`PAINEL_SENHA`). Lê e escreve no mesmo Sheets via `/api/painel`. Coluna O armazena resultado, coluna P armazena observação.
**Consequências:** Zero infraestrutura extra. Senha em variável de ambiente — não é autenticação robusta, adequada apenas para uso interno durante testes.

---

## [DEC-011] — Botões de distribuidor individuais por menção na resposta
**Data:** 21/05/2026 — atualizada em 26/05/2026
**Status:** Ativa (substituiu DEC-011 original de link único para Andreia)
**Contexto:** Botão único "Falar com Distribuidor" sempre apontava para número fixo da Andreia. A Suh menciona distribuidores específicos por região mas o link não refletia isso.
**Decisão:** `renderBotoesDistribuidores()` no ChatWidget detecta quais distribuidores foram mencionados pelo nome no texto da resposta e renderiza um botão individual para cada um com link `wa.me` correto. Fallback: exibe todos os distribuidores se nenhum for identificado.
**Consequências:** Botão agora direciona para o distribuidor correto por região. Depende da Suh mencionar o nome do distribuidor na resposta.

---

## [DEC-012] — tokens_max do agente Comercial em 4096
**Data:** 22/05/2026 — atualizado em 26/05/2026
**Status:** Ativa (substituiu 1024 → 1536 → 3072 → 4096)
**Contexto:** Prompt do agente Comercial consome ~5000 tokens de input. Com limites menores, respostas eram cortadas (finishReason: MAX_TOKENS) em conversas com mais de 5 trocas.
**Decisão:** tokens_max em 4096.
**Consequências:** Elimina cortes em conversas normais. Custo por mensagem ligeiramente maior — irrelevante no volume atual.

---

## [DEC-013] — Mínimo de 2 chars na validação de mensagem
**Data:** 22/05/2026
**Status:** Ativa
**Contexto:** Validação exigia mínimo de 3 chars, bloqueando mensagens legítimas como "SC" e "Ok".
**Decisão:** Reduzir mínimo de 3 para 2 chars.
**Consequências:** Aceita siglas de estado e confirmações curtas. Risco mínimo — outros filtros ainda bloqueiam lixo.

---

## [DEC-014] — Fallback automático para Gemini 2.0 Flash na 3ª tentativa
**Data:** 26/05/2026
**Status:** Ativa
**Contexto:** Gemini 2.5 Flash em preview apresenta 503 frequentes em horário de pico. Após 2 tentativas com backoff, manter o mesmo modelo na 3ª tentativa não agrega — o modelo continua sobrecarregado.
**Decisão:** Na 3ª tentativa de `chamarGeminiComRetry`, o parâmetro `modelo` é trocado automaticamente para `gemini-2.0-flash`. A função `chamarGemini` recebe o modelo como parâmetro e substitui na URL da chamada REST.
**Consequências:** Mantém o atendimento funcionando mesmo com instabilidade do 2.5 Flash. Qualidade da resposta ligeiramente inferior na 3ª tentativa — aceitável. Sem custo adicional de infraestrutura.

---

## [DEC-015] — Limpeza de links WhatsApp no texto exibido ao usuário
**Data:** 26/05/2026
**Status:** Ativa
**Contexto:** A Suh incluía o link da Andreia e o nome "Andreia Knecht — Suporte DKN" no corpo da resposta. O ChatWidget não estava removendo esse conteúdo, exibindo o link cru no chat.
**Decisão:** No `renderMsg` do ChatWidget, remover via regex todos os links `wa.me`/`api.whatsapp.com` e o padrão "Andreia Knecht — Suporte [DKN|Sul Brasil]" do texto exibido. O link ainda é capturado pela `montarLinkWhatsApp` para montar o botão corretamente.
**Consequências:** Interface limpa. O botão continua funcionando. Depende da regex cobrir variações do nome da Andreia no texto.

---

## [DEC-016] — tokens_max do Facilitador em 1024
**Data:** 26/05/2026
**Status:** Ativa (substituiu 150 → 500 → 1024)
**Contexto:** Gemini 2.5 Flash consome tokens internos de "thinking" antes de gerar o output visível. Com tokens_max baixo, o JSON do Facilitador era cortado antes de completar (finishReason: MAX_TOKENS), causando falha no parse e fallback para comercial em todas as requisições.
**Decisão:** tokens_max em 1024. O Facilitador gera ~50-100 tokens de output real — o excedente cobre o thinking interno do modelo.
**Consequências:** Facilitador classifica corretamente. Sem impacto de custo — tokens_max é limite máximo, não tokens cobrados.

---

## [DEC-017] — Remoção do markdown do Gemini antes do JSON.parse do Facilitador
**Data:** 26/05/2026
**Status:** Ativa
**Contexto:** Gemini 2.5 Flash frequentemente retorna o JSON embrulhado em blocos de markdown (```json ... ```), quebrando o `JSON.parse` e causando fallback para comercial.
**Decisão:** Antes do `JSON.parse`, aplicar `.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()` no texto retornado pelo Facilitador.
**Consequências:** Elimina falhas de parse causadas por markdown. Sem efeitos colaterais — a limpeza é inofensiva quando o modelo retorna JSON puro.

---

## [DEC-018] — Agentes RH e Compras implementados
**Data:** 26/05/2026
**Status:** Ativa
**Contexto:** Mensagens de RH (vagas, emprego) e de fornecedores (proposta comercial para a DKN) chegavam na Suh e eram tratadas incorretamente — RH encaminhava para Trabalhe Conosco, Compras não tinha destino definido.
**Decisão:** Dois novos agentes criados em `lib/agents/rh.ts` e `lib/agents/compras.ts`. Registrados no `index.ts` e no `tipos.ts`. Facilitador atualizado com departamento `compras` na lista de classificação.
- Agente RH: informa endereço, horário de atendimento (07h30-08h00, seg-sex) e contato (49) 9356-1517
- Agente Compras: encaminha fornecedores para Josemar — (49) 3561-1519
**Consequências:** Roteamento correto para esses casos. Custo por mensagem muito menor (~600 tokens de input vs ~5800 do Comercial).

---

## [DEC-019] — Referência à empresa como "Grupo Sul Brasil" (não "DKN")
**Data:** 26/05/2026
**Status:** Ativa
**Contexto:** DKN é a marca do produto TNT, não o nome da empresa. Respostas da Suh e dos agentes referenciavam "DKN" como nome da empresa, o que é incorreto.
**Decisão:** Substituir referências isoladas a "DKN" por "Grupo Sul Brasil" ou "Sul Brasil" nos prompts dos agentes e nas mensagens do sistema. Manter "TNT DKN" apenas quando se refere ao produto.
**Consequências:** Comunicação alinhada com a identidade da empresa. Requer atenção em futuras edições de prompt para não regredir.
